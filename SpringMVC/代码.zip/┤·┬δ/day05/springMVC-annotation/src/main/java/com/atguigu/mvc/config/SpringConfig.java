package com.atguigu.mvc.config;

import org.springframework.context.annotation.Configuration;

/**
 * Date:2021/7/10
 * Author:ybc
 * Description:
 */
@Configuration
public class SpringConfig {
}
