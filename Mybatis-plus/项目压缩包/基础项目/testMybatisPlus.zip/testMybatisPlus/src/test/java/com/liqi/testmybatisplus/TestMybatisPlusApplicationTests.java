package com.liqi.testmybatisplus;

import com.liqi.testmybatisplus.mapper.MyUserMapper;
import com.liqi.testmybatisplus.pojo.MyUser;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SpringBootTest
class TestMybatisPlusApplicationTests {

    @Autowired
    private MyUserMapper myUserMapper;

    @Test
    void testSelect() {
        // 通过条件构造器查询一个list集合，若没有条件，则可以设置null参数
        List<MyUser> myUsers = myUserMapper.selectList(null);
        myUsers.forEach(System.out::println);
    }


    @Test
    void testInsert() {
        MyUser myUser = new MyUser();
        myUser.setUsername("ssadas");
        myUser.setAge(44);
        int rest = myUserMapper.insert(myUser);
        System.out.println("rest: " + rest );
    }

    @Test
    void testUpdate() {

        // 通过ID进行更新
        // UPDATE my_user SET username = 'aaaa', age = 20 WHERE id = 1;
        MyUser myUser = new MyUser();
        myUser.setId(1);            // 这个是查找的主键，其他的是要修改的内容
        myUser.setUsername("aaaa");
        myUser.setAge(20);
        int rest = myUserMapper.updateById(myUser);
        System.out.println("rest: " + rest );
    }

    @Test
    void testDelete() {
        // 指定的ID 进行删除
        // DELETE FROM my_user WHERE id = 1;
        int rest = myUserMapper.deleteById(1);
        System.out.println("rest: " + rest );

        // 使用 and 条件进行删除
        // DELETE FROM my_user WHERE username = 'liqi' AND age = 18;
        Map<String, Object> map = new HashMap<>();
        map.put("username", "liqi");
        map.put("age", 18);
        rest = myUserMapper.deleteByMap(map);
        System.out.println("rest: " + rest );

        // 使用 or 条件进行删除
        // DELETE FROM my_user WHERE id = 1 OR id = 2;
        List<Integer> ids = List.of(4, 5);
        rest = myUserMapper.deleteBatchIds(ids);
        System.out.println("rest: " + rest );
    }
}
