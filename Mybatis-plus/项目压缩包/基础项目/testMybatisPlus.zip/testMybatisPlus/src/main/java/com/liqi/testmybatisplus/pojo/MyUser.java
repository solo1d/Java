package com.liqi.testmybatisplus.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("my_user")
public class MyUser {
    @TableId(type = IdType.AUTO)
    private Integer id;

    private Integer age;

    private String username;
}
