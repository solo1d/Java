package com.liqi.testmybatisplus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.liqi.testmybatisplus.pojo.MyUser;
import org.springframework.stereotype.Repository;

 @Repository
public interface MyUserMapper extends BaseMapper<MyUser> {
}
